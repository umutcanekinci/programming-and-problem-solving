public class InvalidBookOperatorException extends Exception{
    public InvalidBookOperatorException() {
        super();
    }

    public InvalidBookOperatorException(String message) {
        super(message);
    }
}
