public class BookLimitException extends Exception {
    public BookLimitException() {
        super();
    }
    
    public BookLimitException(String message) {
        super(message);
    }
}
